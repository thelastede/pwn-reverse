					-NTS-Crackme5

					     By
		
					   Cyclops
-------------------------------------------------------------------------------------------------

Crackme = NTS Crackme5

To_Do
-----

	Create a working keygen.( no self keygenning )

Addons
------
	
	Create a self keygen.

-------------------------------------------------------------------------------------------------

Gr33tz
------
	Greetz to all the reversers,crackers,coders in Reverse Code Engineering field.
	Greetz to all the Programmers who created such nice tools.
	Greetz to crackmes.de, where i started reversing and still learning.
	Greetz to all my friends from RCE world and REAL world, with out em i shouldn't be doin 
	this.

-------------------------------------------------------------------------------------------------

Contact
-------
	U can PM me on crackmes.de or mail me cyclops1428[at]yahoo.com

-------------------------------------------------------------------------------------------------

			   ( Part of Project PolyPhemous (c) Cyclops )