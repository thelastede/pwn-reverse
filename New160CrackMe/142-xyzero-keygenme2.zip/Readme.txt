===================================================
Program	: KeygenMe #2 - Cerebellum
Level	: 2
Author 	: xyzero
Date	: 09.03.2004
Type    : Name/Serial
URL     : http://www.crackmes.de
	  http://www.reversor.web1000.com
===================================================

This is a simple/easy C keygenme.
OPTIONAL: explain the algorithm (easy!)

Rulez:

(1) Make a keygen and write a tutorial.
(2) No patching. No keygen injection. "no surprise".
(3) Enjoy!

===================================================


Greetz to Canterwood, M@rio, OorjaHalT, EXPERTDuke, and YOU ;-)


xyzero
xyzero@hotmail.com